<?php
/**
 * @package   solo
 * @copyright Copyright (c)2014-2024 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

define('AKEEBABACKUP_PRO', '0');
define('AKEEBABACKUP_VERSION', '9.0.5');
define('AKEEBABACKUP_DATE', '2025-07-04');